<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "tujuan@email.com"; // Ganti dengan email tujuan
    $subject = "Data dari Form Input";
    $inputField = $_POST["inputField"];

    $message = "Data yang dikirim: \n\n" . $inputField;

    // Mengirim email
    $headers = "From: webmaster@example.com"; // Ganti dengan email pengirim
    if (mail($to, $subject, $message, $headers)) {
        echo "Email berhasil terkirim.";
    } else {
        echo "Gagal mengirim email.";
    }
}
?>
